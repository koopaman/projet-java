package com.example.projet_interface_cryptos;

public class Bienfinancier {

    public void buy() {
        // Implémentation de la méthode buy
    }

    public void sell() {
        // Implémentation de la méthode sell
    }
}
